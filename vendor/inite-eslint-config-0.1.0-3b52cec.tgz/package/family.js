// The family baseline for a Next 16 app: what `next lint` enforced before
// Next 16 removed it (eslint-config-next core-web-vitals + typescript), run by
// `eslint` itself, with the family's ignores.
//
// Not type-checked on purpose: it reads one file at a time, so it is fast and
// small. Typed linting over a whole app and its submodule is what ran estate
// and rent out of memory (10/2026). A repo that wants more adds blocks after
// this one, e.g. `...family(), ...nextjs` for the strict set.
//
//   // eslint.config.mjs
//   import { family } from '@inite/eslint-config/family';
//   export default family({ ignores: ['src/legacy/**'] });
//
// eslint-config-next is the app's own dependency (every family app has it);
// it is resolved from the app, so this package adds nothing to its lockfile.
import nextVitals from 'eslint-config-next/core-web-vitals';
import nextTs from 'eslint-config-next/typescript';

import { familyIgnores } from './family-ignores.js';

export { familyIgnores };

/**
 * @param {{ ignores?: string[] }} [options]
 * @returns {import('eslint').Linter.Config[]}
 */
export function family({ ignores = [] } = {}) {
  return [{ name: 'inite/family-ignores', ignores: [...familyIgnores, ...ignores] }, ...nextVitals, ...nextTs];
}

export default family();
