# @inite/eslint-config

Shared ESLint flat-config for inite.* apps and packages. ESLint 9+ flat config only.

## Exports

- `@inite/eslint-config` — base config (TypeScript + import-x + perfectionist + sonarjs + selective unicorn + prettier last). Use for non-React packages.
- `@inite/eslint-config/next` — base + React 19 + react-hooks + react-compiler + `@next/eslint-plugin-next` core-web-vitals.
- `@inite/eslint-config/node` — base + Node globals (no DOM).
- `@inite/eslint-config/define` — `defineConfig({ next?: boolean, tailwind?: boolean, scope?: 'src' | 'tests' })` factory.

- `@inite/eslint-config/family` — **the family baseline for a Next 16 app** (`.planning/family-standards-2026-10.md`): eslint-config-next core-web-vitals + typescript — what `next lint` enforced — plus the family ignores (`.next`, `dist`, `inite-shared`, `vendor`, generated, `public`). Untyped, so fast and small. eslint-config-next is resolved from the app.
- `@inite/eslint-config/family-node` — the same for a Node service: `@eslint/js` + typescript-eslint recommended, untyped.
- `@inite/eslint-config/family-ignores` — the ignore list alone, for a repo that keeps a stricter config of its own.

```js
// eslint.config.mjs — every family Next app
import { family } from '@inite/eslint-config/family';
export default family({ ignores: ['src/legacy/**'] });
```

Run it with `sh scripts/family.sh lint` (the `lint` script): eslint with a content cache in `node_modules/.cache/eslint/`, errors held to `.inite/lint-baseline.json`.

## Usage

```js
// eslint.config.js (Next.js app)
import { nextjs } from '@inite/eslint-config/next';

export default [
  ...nextjs,
  { ignores: ['.next/**', 'src/generated/**'] },
];
```

```js
// eslint.config.js (Node library)
import { node } from '@inite/eslint-config/node';

export default [...node];
```

```js
// eslint.config.js (compose via factory)
import { defineConfig } from '@inite/eslint-config/define';

export default defineConfig({ next: true });
```

## Peer dependencies

- `eslint ^9`
- `typescript ^5`

All plugins are direct dependencies of this package.

## Rule highlights

- `max-lines: warn 300` per file
- `max-lines-per-function: warn 80`
- `complexity: warn 15`, `max-depth: warn 4`, `max-params: warn 5`
- `sonarjs/cognitive-complexity: warn 20`
- `@typescript-eslint/consistent-type-imports: error`
- `import-x/no-cycle: error`
- `react-hooks/react-compiler: error` (Next export)
- `i18next/no-literal-string: warn` (Next export) — flags hardcoded
  user-facing JSX strings (`<button>Save</button>`, `<input placeholder="..." />`).

Test files (`**/*.test.*`, `scripts/**`, `e2e/**`) opt out of size/complexity caps and allow `console.log`.

### `i18next/no-literal-string` (Next export)

Surfaces hardcoded user-facing copy that should flow through `t()` / `useT()`.

**Covers:**

- JSX children: `<button>Save</button>` warns.
- JSX human-facing attribute values: `<input placeholder="Имя клиента" />` warns.

**Ignored by default:**

- Calls to `t()`, `useT()`, `getT()`, `i18n(ext)?` and similar i18n helpers.
- DOM / styling / SVG attrs (`className`, `id`, `viewBox`, `d`, `cx`, …).
- Image-extension literals (`.svg`, `.png`, `.jpg`).
- `UPPER_CASE` identifiers, string-literal-typed values, enum members.
- The `<Trans>` component.
- Test / script / e2e / prisma / `*.config.*` files (rule turned off).

**Escape hatches:**

```tsx
{/* eslint-disable-next-line i18next/no-literal-string */}
<span>Brand name (never localized)</span>
```

```tsx
// Type-literal narrowing also suppresses the warning:
const mode: 'create' | 'edit' = 'create';
```

The rule is a **warning**, not an error — pre-commit / pre-push gates are not
blocked. Use it as a backlog signal, fix incrementally as you touch files.
