import nextPlugin from '@next/eslint-plugin-next';
import i18next from 'eslint-plugin-i18next';
import react from 'eslint-plugin-react';
import reactHooks from 'eslint-plugin-react-hooks';

import { base } from './index.js';

const reactBlock = {
  files: ['**/*.{ts,tsx,js,jsx}'],
  plugins: {
    react,
    'react-hooks': reactHooks,
    '@next/next': nextPlugin,
  },
  languageOptions: {
    parserOptions: {
      ecmaFeatures: { jsx: true },
    },
  },
  settings: {
    react: { version: 'detect' },
  },
  rules: {
    ...react.configs.recommended.rules,
    ...reactHooks.configs.recommended.rules,
    ...nextPlugin.configs['core-web-vitals'].rules,
    'react/react-in-jsx-scope': 'off',
    'react/prop-types': 'off',
    'react-hooks/exhaustive-deps': 'error',
    'react-hooks/react-compiler': 'error',
  },
};

// String-marker check: warn when client-only hooks appear in a file that does
// not start with the "use client" directive. We approximate via a no-restricted-syntax
// rule scoped to files without the directive — applied at the no-use-client tier.
const clientHookGuard = {
  files: ['**/*.{ts,tsx}'],
  ignores: ['**/*.test.{ts,tsx}', '**/*.spec.{ts,tsx}'],
  rules: {
    'no-restricted-syntax': [
      'warn',
      {
        // Catches direct use of client-only hooks. Files starting with the
        // "use client" directive opt-in to the override below.
        selector:
          "CallExpression[callee.name=/^(useState|useEffect|useReducer|useLayoutEffect|useRef)$/]",
        message:
          'Client-only hook used. Add the "use client" directive at the top of the file or move the hook into a Client Component.',
      },
    ],
  },
};

const clientFileOverride = {
  files: ['**/*.{ts,tsx}'],
  // ESLint flat config can't read directive prologues directly; teams should
  // place their client components under a known prefix (e.g. *.client.tsx) or
  // rely on @next/next's own rules. We keep this override scoped to files that
  // typically host client hooks and disable the guard there.
  // Conventional Next.js layout: anything under `app/**` may legitimately be a
  // client component, so we surface the rule only as a warning above.
  rules: {},
};

// i18next/no-literal-string: error on hardcoded user-facing JSX strings.
// Catches <button>Save</button> and <input placeholder="Имя клиента" />.
// Ignores className / id / style / SVG path attrs / data-* / etc. (excluded
// below), const A_B = "..." identifiers, string-literal-typed values, "use
// client" / "use server" directives, and calls to project i18n helpers
// (t / useT / getT).
const i18nextBlock = {
  files: ['**/*.{ts,tsx,js,jsx}'],
  plugins: { i18next },
  rules: {
    'i18next/no-literal-string': [
      'error',
      {
        mode: 'jsx-only',
        'should-validate-template': true,
        callees: {
          exclude: [
            'i18n(ext)?',
            't',
            'useT',
            'getT',
            'require',
            'addEventListener',
            'removeEventListener',
            'postMessage',
            'getElementById',
            'dispatch',
            'commit',
            'includes',
            'indexOf',
            'endsWith',
            'startsWith',
          ],
        },
        words: {
          exclude: [
            '[0-9!-/:-@[-`{-~]+',
            '[A-Z_-]+',
            '.+\\.svg$',
            '.+\\.png$',
            '.+\\.jpg$',
            '.+\\.jpeg$',
            '^[\\s\\d\\W]+$',
            // Next.js / React directives — never user copy.
            '^use (client|server|strict)$',
          ],
        },
        'jsx-attributes': {
          exclude: [
            // DOM / styling attrs — never user-facing copy.
            'className',
            'styleName',
            'style',
            'type',
            'key',
            'id',
            'width',
            'height',
            'name',
            'role',
            'rel',
            'target',
            'href',
            'src',
            'value',
            'color',
            'size',
            'tabIndex',
            'autoComplete',
            'autoCorrect',
            'autoCapitalize',
            'spellCheck',
            'inputMode',
            'pattern',
            'min',
            'max',
            'step',
            'method',
            'action',
            'encType',
            // Test / instrumentation.
            'data-testid',
            'data-test',
            'data-cy',
            // Domain-internal field-name pass-through props (not user copy).
            'inputName',
            // SVG.
            'viewBox',
            'fill',
            'stroke',
            'd',
            'strokeLinecap',
            'strokeLinejoin',
            'strokeWidth',
            'strokeMiterlimit',
            'strokeDasharray',
            'fillRule',
            'clipRule',
            'x',
            'y',
            'x1',
            'y1',
            'x2',
            'y2',
            'cx',
            'cy',
            'r',
            'rx',
            'ry',
            'transform',
            'points',
            'preserveAspectRatio',
            'xmlns',
            'gradientUnits',
            'gradientTransform',
            'offset',
            'stopColor',
            'stopOpacity',
            // Next.js / framework specifics.
            'as',
            'priority',
            'loading',
            'fetchPriority',
            'crossOrigin',
            'referrerPolicy',
            'sizes',
            'srcSet',
          ],
        },
        'jsx-components': {
          exclude: ['Trans'],
        },
      },
    ],
  },
};

// Tests, scripts, e2e, prisma seeds, generated code, and Next.js metadata /
// route files often contain English literals (test fixtures, log strings,
// SEO copy, mock data). Turn the rule off for those so the signal-to-noise
// ratio in product code stays high.
const i18nextOffOverride = {
  files: [
    '**/*.test.{ts,tsx,js,jsx}',
    '**/*.spec.{ts,tsx,js,jsx}',
    'e2e/**',
    'scripts/**',
    'prisma/**',
    '**/*.config.{js,mjs,cjs,ts}',
  ],
  rules: {
    'i18next/no-literal-string': 'off',
  },
};

// Date/time/number formatting guard. Forbid direct
// `.toLocaleDateString/.toLocaleTimeString/.toLocaleString` and
// `new Intl.{DateTimeFormat,NumberFormat,PluralRules}` in app code; force every
// call site through @inite/utils' formatDate/formatTime/formatDateTime/
// formatNumber/formatPlural. The helpers default to the device locale
// (navigator.language) so output follows the user's OS settings; explicit
// locale overrides are only for business-frozen surfaces (DOCX contracts =
// always RU, LLM prompts = always EN, OG-image PNGs = route-locale).
const formatGuardScope = [
  'src/app/**/*.{ts,tsx}',
  'src/components/**/*.{ts,tsx}',
  'src/hooks/**/*.{ts,tsx}',
];
const formatGuardBlock = {
  files: formatGuardScope,
  ignores: [
    '**/*.test.{ts,tsx}',
    '**/*.spec.{ts,tsx}',
    // LLM prompts must be EN-frozen regardless of UI locale.
    'src/lib/domain/assistant/prompts/**',
  ],
  rules: {
    'no-restricted-syntax': [
      'error',
      {
        selector:
          "CallExpression[callee.property.name=/^toLocale(Date|Time)?String$/]",
        message:
          'Use formatDate/formatTime/formatDateTime from @inite/utils. Defaults to device locale (navigator.language); pass an explicit locale only for business-frozen surfaces (DOCX, LLM prompts, OG images).',
      },
      {
        selector:
          "NewExpression[callee.object.name='Intl'][callee.property.name=/^(DateTimeFormat|NumberFormat|PluralRules)$/]",
        message:
          'Use formatDate/formatTime/formatDateTime/formatNumber/formatPlural from @inite/utils — direct new Intl.* bypasses the helpers (which default to device locale).',
      },
    ],
  },
};

export const nextjs = [
  ...base,
  reactBlock,
  clientHookGuard,
  clientFileOverride,
  i18nextBlock,
  i18nextOffOverride,
  formatGuardBlock,
];

export default nextjs;
