import js from '@eslint/js';
import prettier from 'eslint-config-prettier';
import importX from 'eslint-plugin-import-x';
import perfectionist from 'eslint-plugin-perfectionist';
import sonarjs from 'eslint-plugin-sonarjs';
import unicorn from 'eslint-plugin-unicorn';
import globals from 'globals';
import tseslint from 'typescript-eslint';

const ignores = {
  ignores: [
    'src/generated/**',
    '**/generated/**',
    '.next/**',
    'node_modules/**',
    'dist/**',
    'build/**',
    'coverage/**',
    '**/*.tsbuildinfo',
  ],
};

const recommended = [
  js.configs.recommended,
  ...tseslint.configs.recommendedTypeChecked,
  ...tseslint.configs.stylisticTypeChecked,
];

const baseRules = {
  files: ['**/*.{ts,tsx,js,jsx,mjs,cjs}'],
  plugins: {
    'import-x': importX,
    perfectionist,
    sonarjs,
    unicorn,
  },
  languageOptions: {
    ecmaVersion: 2023,
    sourceType: 'module',
    globals: {
      ...globals.node,
      ...globals.browser,
      ...globals.es2023,
    },
  },
  settings: {
    // Consumers using TypeScript paths should add:
    //   `eslint-import-resolver-typescript` as a dev-dep and
    //   `'import-x/resolver': { typescript: true, node: true }` in their config.
    // We default to node-only resolution here to avoid forcing the TS resolver dep.
    'import-x/resolver': {
      node: true,
    },
  },
  rules: {
    'no-console': ['error', { allow: ['warn', 'error'] }],
    '@typescript-eslint/consistent-type-imports': 'error',
    '@typescript-eslint/no-explicit-any': 'warn',
    '@typescript-eslint/no-unused-vars': [
      'error',
      {
        argsIgnorePattern: '^_',
        varsIgnorePattern: '^_',
        caughtErrorsIgnorePattern: '^_',
      },
    ],
    'import-x/no-cycle': 'error',
    'max-lines': ['warn', 300],
    'max-lines-per-function': [
      'warn',
      { max: 80, skipBlankLines: true, skipComments: true },
    ],
    complexity: ['warn', 15],
    'max-depth': ['warn', 4],
    'max-params': ['warn', 5],
    'sonarjs/cognitive-complexity': ['warn', 20],
    'perfectionist/sort-imports': [
      'warn',
      {
        type: 'natural',
        order: 'asc',
        groups: [
          'builtin',
          'external',
          'internal',
          'parent',
          'sibling',
          'index',
          'object',
          'type',
        ],
      },
    ],
    // Unicorn: enable a few high-signal rules and turn off the noisy ones.
    // Rule names verified against eslint-plugin-unicorn@56.
    'unicorn/consistent-function-scoping': 'error',
    'unicorn/no-useless-promise-resolve-reject': 'error',
    'unicorn/no-array-for-each': 'off',
    'unicorn/prevent-abbreviations': 'off',
    'unicorn/filename-case': 'off',
    'unicorn/no-null': 'off',
  },
};

const testOverrides = {
  files: [
    '**/*.test.ts',
    '**/*.test.tsx',
    '**/*.spec.ts',
    '**/*.spec.tsx',
    'scripts/**',
    'e2e/**',
  ],
  rules: {
    'max-lines': 'off',
    'max-lines-per-function': 'off',
    'no-console': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    'sonarjs/cognitive-complexity': 'off',
  },
};

export const base = [ignores, ...recommended, baseRules, testOverrides, prettier];

export default base;
