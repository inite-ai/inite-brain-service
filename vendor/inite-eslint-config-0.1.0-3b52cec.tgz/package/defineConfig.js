import { base } from './index.js';
import { nextjs } from './next.js';

/**
 * Compose a flat-config array tailored to a project.
 *
 * @param {{ next?: boolean, tailwind?: boolean, scope?: 'src' | 'tests' }} [options]
 * @returns {import('eslint').Linter.Config[]}
 */
export function defineConfig(options = {}) {
  const { next = false, scope } = options;

  let config = next ? [...nextjs] : [...base];

  if (scope === 'tests') {
    config = [
      ...config,
      {
        files: ['**/*'],
        rules: {
          'max-lines': 'off',
          'max-lines-per-function': 'off',
          'no-console': 'off',
        },
      },
    ];
  }

  return config;
}

export default defineConfig;
