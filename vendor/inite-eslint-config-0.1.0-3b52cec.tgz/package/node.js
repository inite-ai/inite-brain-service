import globals from 'globals';

import { base } from './index.js';

const nodeBlock = {
  files: ['**/*.{ts,js,mjs,cjs}'],
  languageOptions: {
    globals: {
      ...globals.node,
    },
  },
};

export const node = [...base, nodeBlock];

export default node;
