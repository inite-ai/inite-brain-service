// The family baseline for a Node service (Nest, workers, CLIs):
// @eslint/js recommended + typescript-eslint recommended, untyped, with the
// family's ignores. A service with a stricter config of its own keeps it and
// adds `familyIgnores` to it.
//
//   // eslint.config.mjs
//   import { familyNode } from '@inite/eslint-config/family-node';
//   export default familyNode();
import js from '@eslint/js';
import globals from 'globals';
import tseslint from 'typescript-eslint';

import { familyIgnores } from './family-ignores.js';

export { familyIgnores };

/**
 * @param {{ ignores?: string[] }} [options]
 * @returns {import('eslint').Linter.Config[]}
 */
export function familyNode({ ignores = [] } = {}) {
  return [
    { name: 'inite/family-ignores', ignores: [...familyIgnores, ...ignores] },
    js.configs.recommended,
    ...tseslint.configs.recommended,
    {
      name: 'inite/family-node',
      languageOptions: { globals: { ...globals.node, ...globals.jest } },
      rules: {
        '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_', varsIgnorePattern: '^_', caughtErrorsIgnorePattern: '^_' }],
      },
    },
  ];
}

export default familyNode();
