// The paths no family repo lints, shared by the next and node presets.
/** What no family repo lints: build output, dependencies, vendored and generated code. */
export const familyIgnores = [
  '**/node_modules/**',
  '.next/**',
  'out/**',
  'build/**',
  'dist/**',
  'coverage/**',
  '.turbo/**',
  '.vercel/**',
  'playwright-report/**',
  'test-results/**',
  'inite-shared/**',
  'vendor/**',
  '**/generated/**',
  'public/**',
  'next-env.d.ts',
  '**/*.min.js',
];
