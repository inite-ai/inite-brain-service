/**
 * @inite/landing — Tailwind 3 preset.
 *
 *   // tailwind.config.js
 *   presets: [require('@inite/landing/tailwind-preset')],
 *   content: [..., './inite-shared/packages/landing/src/**\/*.{ts,tsx}'],
 *
 * ADDITIVE ONLY. It adds the family names (ink, bone, graphite, signal,
 * rule, moss, warning, danger; font-display; the display scale) and never
 * redefines a Tailwind default a site's app may already use — with one
 * exception, `font-mono`, which resolves to --family-mono when a family
 * wrapper defines it and to the ordinary monospace stack everywhere else.
 *
 * Colours resolve through rgb(var(--x-rgb) / <alpha-value>), the mechanism
 * all three editorial references share, so `bg-bone/[0.06]` works. Outside a
 * [data-family] element the variables are undefined and these utilities
 * render nothing — which is the point: they cannot leak into an app.
 */
const rgb = (name) => `rgb(var(--${name}-rgb) / <alpha-value>)`;

module.exports = {
  theme: {
    extend: {
      colors: {
        ink: rgb('ink'),
        bone: rgb('bone'),
        graphite: rgb('graphite'),
        signal: rgb('signal'),
        moss: rgb('moss'),
        warning: rgb('warning'),
        danger: rgb('danger'),
        rule: 'var(--rule)',
        'rule-strong': 'var(--rule-strong)',
      },
      // Objects, not strings: an app on shadcn/ui already has `secondary` and
      // `muted` colours with a `foreground` shade. A string here would replace
      // that whole entry in textColor and delete `text-muted-foreground` and
      // `text-secondary-foreground` from the app; an object merges, so only
      // the bare `text-secondary` / `text-muted` (family-only) are added.
      textColor: {
        secondary: { DEFAULT: 'var(--text-secondary)' },
        muted: { DEFAULT: 'var(--text-muted)' },
        'btn-fg': 'var(--btn-fg)',
      },
      backgroundColor: {
        btn: 'var(--btn-bg)',
        'btn-hover': 'var(--btn-bg-hover)',
      },
      borderColor: {
        btn: 'var(--btn-bg)',
        'btn-hover': 'var(--btn-bg-hover)',
      },
      fontFamily: {
        display: ['var(--family-display, var(--family-body, ui-sans-serif))', 'system-ui', 'sans-serif'],
        body: ['var(--family-body, ui-sans-serif)', 'system-ui', 'sans-serif'],
        mono: [
          'var(--family-mono, ui-monospace)',
          'ui-monospace',
          'SFMono-Regular',
          'Menlo',
          'Monaco',
          'Consolas',
          'monospace',
        ],
      },
      fontSize: {
        'mono-eyebrow': ['0.75rem', { lineHeight: '1', letterSpacing: '0.14em' }],
        label: ['0.6875rem', { lineHeight: '1', letterSpacing: '0.08em' }],
        num: ['0.75rem', { lineHeight: '1', letterSpacing: '0.02em' }],
        'body-lg': ['1.25rem', { lineHeight: '1.55' }],
        'display-sm': ['2.25rem', { lineHeight: '1.08', letterSpacing: '-0.02em' }],
        'display-md': ['3.25rem', { lineHeight: '1.04', letterSpacing: '-0.02em' }],
        'display-lg': ['4.75rem', { lineHeight: '1.0', letterSpacing: '-0.025em' }],
        'display-xl': ['6rem', { lineHeight: '0.96', letterSpacing: '-0.03em' }],
      },
      letterSpacing: {
        // Labels 0.08em, nav and marks 0.14em (plan §2.2).
        'mono-label': '0.08em',
        'mono-eyebrow': '0.14em',
      },
      maxWidth: { editorial: '1440px' },
      borderRadius: {
        editorial: '4px',
        panel: '14px',
      },
    },
  },
};
